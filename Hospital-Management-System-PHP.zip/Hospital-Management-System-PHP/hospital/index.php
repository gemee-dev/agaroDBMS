
<?php
include_once('hms/include/config.php');
if(isset($_POST['submit']))
{
$name=$_POST['fullname'];
$email=$_POST['emailid'];
$mobileno=$_POST['mobileno'];
$dscrption=$_POST['description'];
$query=mysqli_query($con,"insert into tblcontactus(fullname,email,contactno,message) value('$name','$email','$mobileno','$dscrption')");
echo "<script>alert('Your information succesfully submitted');</script>";
echo "<script>window.location.href ='index.php'</script>";

} ?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> Agaro Health Center Database Management System</title>

    <link rel="shortcut icon" href="assets/images/fav.jpg">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawsom-all.min.css">
     <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
    <script> src="hms\vendor\bootstrap\js\bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome for Icons -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  
   <!-- Bootstrap CSS -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Font Awesome for Icons -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
  body {
    background: #f8f9fa;
    font-family: Arial, sans-serif;
    text-decoration: none !important;
    width: 100%;
   
   
  }
  
  .form-control {
    
    color: #000; 
    border: 1px solid #007bff;

  }
    .form-control:focus {
        border-color: #007bff;
        box-shadow: none;
    
    }
  
  nav-item ul li a {
    color: #000 !important;
    font-size: 1.2rem;
    font-weight: bold;
    text-decoration: none !important;
  }
  .single-key {
   
    border-radius: 20px;
    padding: 20px;
    border: 1px solid #007bff;
    box-sizing: border-box;
    box-shadow: 0 0 20px rgba(20, 1, 1, 0.58);
    text-align: center;
    width: 100%;
    
  }
  .content{
    border-radius: 20px;
    padding: 80px;
    margin:10px 10px 80px 10px;
    border-radius:20px
    
    text-align: center;
   box-shadow: 0 0 20px rgba(20, 1, 1, 0.58);
    border: 1px solid #007bff;
    background:#ffff;
    border-radius:20px;
    text-align: center;
    
    
  }
 
  

  .single-key i {
    font-size: 2rem;
    color: #007bff;
    margin-bottom: 10px;
    display: flex;
    justify-content: center;
  }
  .dropdown-toggle {
    font-size: 1rem;
  }
  .container {
    max-width: 100%;
    margin: 0 auto;
    left: 0; 
  }
  .header-nav ul li a {
  all: unset;
  cursor: pointer;
}
.blog-single-det{
    text-align: center;
    padding: 20px;
   
    border-radius: 20px;
    margin-top: 10px;
}
#contact_us  {
    padding: 20px;
    color: #000;
    font-size: 1.2rem;
    font-weight: bold;
    margin:0px 10px 80px 10px;
    border-radius:20px;
    text-align: center;
   box-shadow: 0 0 6px 4px rgba(0, 0, 0, 0.1);

    border-radius:20px;
   
    

}

 @media (min-width: 1280px) {
  .content {
    margin:0px 100px 100px 100px;
  }
    #contact_us {
      max-width: 75%;
      margin:12.5%;
      
    }
    .single-key {
      max-width: 75%;
      margin: 12.5%;;
    }
    #hover:hover {
  border: 1px solid #007bff;
   box-shadow: 0 0 6px 4px #007bff;
   
    }
    #contact_us:hover{
      border: 1px solid #007bff;
      box-shadow: 0 0 6px 4px #007bff;
    }
   
</style>
</head>
<body>
    <!-- ################# Header Starts Here#######################--->
    
      <header id="menu-jk">
    
        <div id="nav-head" class="header-nav">
            <div class="container">
                <div class="row">
                    <div class="col-lg-2 col-md-3  col-sm-12" style="color:#000;font-weight:bold; font-size:42px; margin-top: 1% !important;">AHC
                       <a data-toggle="collapse" data-target="#menu" href="#menu" ><i class="fas d-block d-md-none small-menu fa-bars"></i></a>
                    </div>
                    <div id="menu" class="col-lg-8 col-md-9 d-none d-md-block nav-item">
                        <ul>
                            <li><a href="#">Home</a></li>
                            <li><a href="#services">Services</a></li>
                            <li><a href="#about_us">About Us</a></li>
                    
                            <li><a href="#contact_us">Contact Us</a></li>
                            <li><a href="#logins">Logins</a></li>  
                        </ul>
                    </div>
                    <div class="col-sm-2 d-none d-lg-block appoint">
                        <a class="btn btn-success" href="hms/user-login.php">Book an Appointment</a>
                    </div>
                </div>

            </div>
        </div>
    </header>
    
     <!-- ################# Slider Starts Here#######################--->

    <div class="slider-detail">

        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            </ol>


   


            <div class="carousel-inner">
                <div class="carousel-item ">
                    <img class="d-block w-100" src="assets\images\slider\slider3.jpg" alt="Second slide">
                    <div class="carousel-cover"></div>
                    <div class="carousel-caption vdg-cur d-none d-md-block">
                        <h5 class="animated bounceInDown">Agaro Health Center Database Management System</h5>
                    </div>
                </div>
                
                <div class="carousel-item active">
                    <img class="d-block w-100" src="assets/images/slider/slider2.jpg" alt="Third slide">
                      <div class="carousel-cover"></div>
                    <div class="carousel-caption vdg-cur d-none d-md-block">
                        <h5 class="animated bounceInDown">Agaro Health Center Database Management System</h5>
            
                         
                    
                    </div>
              
                </div>
                
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>


    </div>
    
  <!--  ************************* Logins ************************** -->
    
    
     <section id="logins" class="our-blog container-fluid">
        <div class="container">
        <div class="inner-title">

                <h2>Logins</h2>
            </div>
            <div class="col-sm-12 blog-cont">
                <div class="row no-margin">
                    <div class="col-sm-4 blog-smk">
                        <div class="blog-single">

                                <img src="assets/images/patient.jpg" alt="">

                            <div class="blog-single-det">
                                <h6>Patient Login</h6>
                                <a href="hms/user-login.php" target="_blank">
                                    <button class="btn btn-success btn-sm">Click Here</button>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4 blog-smk">
                        <div class="blog-single">

                                <img src="assets/images/doctor.jpg" alt="">

                            <div class="blog-single-det">
                                <h6>Doctors login</h6>
                                <a href="hms/doctor" target="_blank">
                                    <button class="btn btn-success btn-sm">Click Here</button>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-4 blog-smk">
                        <div class="blog-single">

                                <img src="assets/images/admin.jpg" alt="">

                            <div class="blog-single-det">
                                <h6>Admin Login</h6>
                    
                                <a href="hms/admin" target="_blank">
                                    <button class="btn btn-success btn-sm">Click Here</button>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    
                    

                    
                    
                </div>
            </div>
            
        </div>
    </section>  







    <!-- ################# Our Departments Starts Here#######################--->


<section id="services" class="key-features department">
  <div class="container">
    <div class="inner-title">
       <h2>Our services </h2>
        <p>Take a look at some of our services</p>
    </div>
<div class="container">

      <!-- Exempted Services Dropdown -->


<div class="row" >

    <!-- Exempted Services Dropdown -->
    <div class="col-lg-4 col-md-6">
      <div class="single-key" id="hover">
        <i class="fas fa-heartbeat"></i>
        <div class="dropdown" >
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownExemptedServices" data-bs-toggle="dropdown" aria-expanded="false" style="background:transparent; color:#000; border:none; font-weight:bold;">
            Exempted Services
          </button>
          <ul class="dropdown-menu" aria-labelledby="dropdownExemptedServices">
            <li><a class="dropdown-item" href="#">Emergency Outpatient Services</a></li>
            <li><a class="dropdown-item" href="#">Maternal to Child Service</a></li>
            <li><a class="dropdown-item" href="#">ERT Service</a></li>
            <li><a class="dropdown-item" href="#">OPD Service</a></li>
            <li><a class="dropdown-item" href="#">EPI Service</a></li>
            <li><a class="dropdown-item" href="#">Abortion Service</a></li>
            <li><a class="dropdown-item" href="#">Family Planning Service</a></li>
            <li><a class="dropdown-item" href="#">User Friendly Services</a></li>
          </ul>
        </div>
      </div>
    </div>

    <!-- Laboratory Service Dropdown -->
    <div class="col-lg-4 col-md-6">
      <div class="single-key" id="hover">
        <i class="fas fa-ribbon"></i>
        <div class="dropdown">
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownLabService" data-bs-toggle="dropdown" aria-expanded="false" style="background:transparent; color:#000; border:none; font-weight:bold;">
            Laboratory Service
          </button>
          <ul class="dropdown-menu" aria-labelledby="dropdownLabService">
            <li><a class="dropdown-item" href="#">Routine Laboratory Test</a></li>
            <li><a class="dropdown-item" href="#">Chemistry Test</a></li>
            <li><a class="dropdown-item" href="#">Hematology</a></li>
            <li><a class="dropdown-item" href="#">Scrology</a></li>
            <li><a class="dropdown-item" href="#">CD4 Test</a></li>
            <li><a class="dropdown-item" href="#">AFB Test</a></li>
          </ul>
        </div>
      </div>
    </div>

    <!-- Diagnostics Service Dropdown -->
    <div class="col-lg-4 col-md-6">
      <div class="single-key" id="hover">
        <i class="fab fa-monero"></i>
        <div class="dropdown">
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownDiagnostics" data-bs-toggle="dropdown" aria-expanded="false" style="background:transparent; color:#000; border:none; font-weight:bold;">
            Diagnostics Service
          </button>
          <ul class="dropdown-menu" aria-labelledby="dropdownDiagnostics">
            <li><a class="dropdown-item" href="#">Ultrasound</a></li>
            <li><a class="dropdown-item" href="#">Centrifuge</a></li>
          </ul>
        </div>
      </div>
    </div>
               <div class="col-lg-4 col-md-6">
                    <div class="single-key" id="hover">
                        <i class="fas fa-capsules"></i>
                        <h5>Pharmacy service</h5>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="single-key" id="hover">
                        <i class="fas fa-prescription-bottle-alt"></i>
                        <h5>insurance service</h5>
                    </div>
                </div>



                <div class="col-lg-4 col-md-6">
                    <div class="single-key" id="hover">
                        <i class="far fa-thumbs-up"></i>
                        <h5>referral service</h5>

                    </div>
                </div>
            </div>



        </div>

      </div>
    </div>
 </div>

</section>
    
    
  
    
    <!--  ************************* About Us Starts Here ************************** -->
        
    <section id="about_us" class="about-us">
    <div class="content" id="hover">
            <div>
                <h3>About Our Health center</h3>
           </div>
    <?php
  $ret=mysqli_query($con,"select * from tblpage where PageType='aboutus' ");
  while ($row=mysqli_fetch_array($ret)) {
  ?>
  <p>
      <?php  echo $row['PageDescription'];?>.
      </p>
      <?php } 
      
  ?>
            
  </div>
  </section>    
      
    
</div>
    
    
     <!--  ************************* Contact Us Starts Here ************************** -->
    
    <section id="contact_us" class="contact-us-single" >
        <div class="row no-margin" id="ho">

            <div  class="col-sm-12 cop-ck">
                <form method="post">
                <h2 >Contact Form</h2>
                    <div class="row cf-ro">
                        <div  class="col-sm-3 "><label>Enter Name :</label></div>
                        <div class="col-sm-8"><input type="text" placeholder="Enter Name" name="fullname" class="form-control input-sm" required ></div>
                    </div>
                    <div  class="row cf-ro">
                        <div  class="col-sm-3"><label>Email Address :</label></div>
                        <div class="col-sm-8"><input type="text" name="emailid" placeholder="Enter Email Address" class="form-control input-sm"  required></div>
                    </div>
                     <div  class="row cf-ro">
                        <div  class="col-sm-3"><label>Mobile Number:</label></div>
                        <div class="col-sm-8"><input type="text" name="mobileno" placeholder="Enter Mobile Number" class="form-control input-sm" required ></div>
                    </div>
                     <div  class="row cf-ro">
                        <div  class="col-sm-3"><label>Enter  Message:</label></div>
                        <div class="col-sm-8">
                          <textarea rows="5" placeholder="Enter Your Message" class="form-control input-sm" name="description" required></textarea>
                        </div>
                    </div>
                     <div  class="row cf-ro">
                        <div  class="col-sm-3"><label></label></div>
                        <div class="col-sm-8">
                         <button class="btn btn-success btn-sm" type="submit" name="submit">Send Message</button>
                        </div>
                </div>
            </form>
            </div>
     
        </div>
    </section>
    
    
    
    </div>
    
    <!-- ################# Footer Starts Here#######################--->


    <footer class="footer">
        <div class="container">
            <div class="row">
       
                <div class="col-md-6 col-sm-12">
                    <h2>Useful Links</h2>
                    <ul class="list-unstyled link-list">
                        <li><a ui-sref="about" href="#about_us">About us</a><i class="fa fa-angle-right"></i></li>
                        <li><a ui-sref="portfolio" href="#services">Services</a><i class="fa fa-angle-right"></i></li>
                        <li><a ui-sref="products" href="#logins">Logins</a><i class="fa fa-angle-right"></i></li>
                      
                        <li><a ui-sref="contact" href="#contact">Contact us</a><i class="fa fa-angle-right"></i></li>
                    </ul>
                </div>
                <div class="col-md-6 col-sm-12 map-img">
                    <h2>Contact Us</h2>
                    <address class="md-margin-bottom-40">

<?php
$ret=mysqli_query($con,"select * from tblpage where PageType='contactus' ");
while ($row=mysqli_fetch_array($ret)) {
?>


                        <?php  echo $row['PageDescription'];?> <br>
                        Phone: <?php  echo $row['MobileNumber'];?> <br>
                        Email: <a href="mailto:<?php  echo $row['Email'];?>" class=""><?php  echo $row['Email'];?></a><br>
                        Timing: <?php  echo $row['OpenningTime'];?>
                    </address>

        <?php } ?>





                </div>
            </div>
        </div>
        

    </footer>
    <div class="copy">
            <div class="container">
            Agaro Health Center Database Management System
                
     
            </div>

        </div>
    
    </body>

<script src="assets/js/jquery-3.2.1.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/plugins/scroll-nav/js/jquery.easing.min.js"></script>
<script src="assets/plugins/scroll-nav/js/scrolling-nav.js"></script>
<script src="assets/plugins/scroll-fixed/jquery-scrolltofixed-min.js"></script>

<script src="assets/js/script.js"></script>
<!-- Bootstrap JS Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>



</html>